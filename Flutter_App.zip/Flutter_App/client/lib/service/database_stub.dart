import 'package:client/service/database_manager.dart';

DatabaseManager getDatabaseManager() => throw UnsupportedError("Unsupported type");